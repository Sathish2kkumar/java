package problems;

import java.util.Scanner;

public class find_largest_contagious_values {
    public static void main(String[] args) {
        Scanner a = new Scanner(System.in);
        int b = a.nextInt();
        Scanner d=  new Scanner(System.in);
        int[] input = new int[b];
        for(int i=0;i<b;i++)
            input[i]=d.nextInt();
        for(int j:input)
            System.out.println(j);
        for(int k:input);


    }
}

