package problems;

import java.util.*;
import java.util.stream.Collectors;

public class removeelementmatches_ {
    public static void main(String[] args) {
        int nums[] = {3,2,2,3,5,5,5,5,5,5,};
        List<Integer> uniquevalues = new ArrayList<>();
        for(int i=0;i<nums.length;i++){
            int count = 0;
            for(int j=i+1;j<nums.length;j++){
                if(nums[i]==nums[j]){
                  count++;
                }
                if(count>0){
                   uniquevalues.add(nums[j]);
                }
            }
            count=0;
        }
        System.out.println("systemoutput"+uniquevalues);

    }
    public static int removeElement(int[] nums, int val) {
        List<Integer> onedata = new ArrayList<>();
        for(int intvalue:nums){
            if(intvalue!=val){
                onedata.add(intvalue);
            }
        }
        return onedata.size();
    }
}
