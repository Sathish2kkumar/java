package streaming;

import java.util.Arrays;
import java.util.List;

public class problem_5 {
    public static void main(String[] args) {
        List<String> usernames = Arrays.asList("Sathish","ramesh","Suresh","mahendran","manikkam");
        System.out.println(filteringthestringsthatstartswithS(usernames));
    }
    public static List<String> filteringthestringsthatstartswithS(List<String> stringdata){
        return stringdata.stream().filter(data->data.startsWith("S")).toList();
    }
}
