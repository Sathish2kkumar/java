package generics;

public class generics {
    public static void main(String[] args) {
        Integer b =10;
        generics_2 c = new generics_2(10);
        generics_1 a = new generics_1();
        a.print(c);
    }
}
