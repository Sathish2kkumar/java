package generics;

public class generics_2 {
    Integer b =450;

    public generics_2(Integer b) {
        this.b = b;
    }
}
