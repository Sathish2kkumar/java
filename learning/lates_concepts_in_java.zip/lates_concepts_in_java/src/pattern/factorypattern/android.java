package pattern.factorypattern;

public class android implements os{
    public void operatingsystem(){
        System.out.println("more advanced");
    }
}
