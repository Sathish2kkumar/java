package pattern.factorypattern;

public interface os {
    void operatingsystem();
}
