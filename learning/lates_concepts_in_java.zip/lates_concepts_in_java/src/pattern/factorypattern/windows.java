package pattern.factorypattern;

public class windows implements os{
    public void operatingsystem(){
        System.out.println("user friendly");
    }
}
