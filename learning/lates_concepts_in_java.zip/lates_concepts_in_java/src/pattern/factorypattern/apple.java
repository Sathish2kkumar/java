package pattern.factorypattern;

public class apple implements os{
    public void operatingsystem(){
        System.out.println("securedos");
    }
}
