package pattern.decoratorpattern;

public interface burger {
    String bun();
    String meat();
}
