package pattern.decoratorpattern;

public class recipie implements burger{
    public String bun(){

        return "Soft and Smooth";
    }
    public String meat(){

        return "mutton";
    }
}
