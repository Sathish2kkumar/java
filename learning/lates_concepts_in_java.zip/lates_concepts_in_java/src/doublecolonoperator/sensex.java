package doublecolonoperator;

@FunctionalInterface
public interface sensex {
    public void d(String a);
}
