package delegates_in_java;

public interface printing_name {
    void gettingname();
}
